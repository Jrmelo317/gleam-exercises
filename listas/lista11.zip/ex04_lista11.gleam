import sgleam/check
import gleam/string

/// Essa função tem como objetivo resolver de duas maneiras o mesmo problema, primeiro utilizando funções
/// prontas e depois resolvendo com rescursão. O problema é que, se uma String for vazia ou tiver apenas
/// um caracter, ela se mantém igual. Se não, removemos o primeiros e último caracter dela, invertemos ela
/// e colocamos o primeiro caracter como ultimo e o ultimo como primeiro.

/// Análise do Tempo de Execução:
/// Essa função possui tempo de processamento constante internamente, porém ela possui uma recursão, que chama-se
/// a si mesma o número de n / 2 vezes assin O(n / 2) ou simplesmente O(n).

pub fn inverte_with_functions(word: String) -> String {
    let size = string.length(word)

    case word {
        _ if size < 2 -> word
        _ -> {
            // Primeiro caracter removedo usando o slice
            let first = string.slice(word, 0, 1)
            //Segundo caracter removendo usando o slice
            let last = string.slice(word, -1, 1)
            // Parte do meio tirando o início e o fim
            let mid = string.slice(word, 1, string.length(word) - 2)

            last <> inverte_with_functions(mid) <> first
        }
    }
}

pub fn inverte_with_functions_examples() {
    check.eq(inverte_with_functions("a"), "a")
    check.eq(inverte_with_functions(""), "")
    check.eq(inverte_with_functions("Joao"), "oaoJ")
    check.eq(inverte_with_functions("Paulo"), "oluaP")
    check.eq(inverte_with_functions("Leonardo"), "odranoeL")
}