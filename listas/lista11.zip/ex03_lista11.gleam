import sgleam/check
import gleam/int

/// Essa função tem como objetivo realizar a análise do seu tempo de execução em dois casos. Primeiro caso
/// caso o número recebido por ela seja menor ou igual a 10. O segundo caso se o npumero for maior. No primeiro
/// caso apenas convertemos o número para String, no segundo caso separamos o último digito do número dele,
/// transformamos as duas partes em string e depois juntamos ela.

/// Análise do Tempo de Execução:
/// Ambas as funções não possuem recursão, logo seu tempo de execução não aumenta se mantendo assim sempre
/// constante, então o tempo de execução é constante.

pub fn transform_to_string(num: Int) -> String {
    case num {
        _, if num <= 10 -> int.to_string(num)
        _ -> {
            let first = num % 10
            let rest = num / 10
            int.to_string(rest) <> int.to_string(first)
        }
    } 
}

pub fn transform_to_string_examples() {
    check.eq(transform_to_string(451), "451")
    check.eq(transform_to_string(0), "0")
    check.eq(transform_to_string(1501), "1501")
}