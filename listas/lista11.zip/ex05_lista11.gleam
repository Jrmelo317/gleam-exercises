import sgleam/check
import gleam/list
import gleam/int

/// O objetivo desta função é obter o valor máximo de uma lista de números não vazia
/// usando recursão, para isso consideramos dividir a lista ao meio e encontrar recursivamente
/// o maior valor de cada lista, assim o maior valor será o maior valor de uma das listas que comparamos.
/// Caso a lista tenha um único valor, ele é o maior valor, se não, comparamos até que achemos
/// o maior valor.

/// Análise de Tempo de Execução:
/// A análise seria que para cada n tenho 2n de chamadas em média, mas em cada chamada também chamo spli, então seria
/// 2n com n ao quadrado, logo, O(n quadrado)

pub fn biggest_value(values: List(Int)) -> Int {
    case values {
        [single] -> single
        _ -> {
            let #(front, back) = list.split(values, list.length(values) / 2)
            int.max(biggest_value(front), biggest_value(back))
        }
    }
}

pub fn biggest_value_examples() {
    check.eq(biggest_value([1, 2, 3, 4, 5]), 5)
    check.eq(biggest_value([10, 9, 8, 3, 11, 20, 33]), 33)
    check.eq(biggest_value([1, 5, 3, 4, 1]), 5)
}