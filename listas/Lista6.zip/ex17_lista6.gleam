import sgleam/check

pub type Arvore(a) {
    Vazia
    No(val: a, dir: Arvore(a), esq: Arvore(a))
}


/// Essa função deve verificar se uma árvore é de busca, ou seja, valores e sua esquerda
/// são menores e a direita maiores, e isso serve para todos os nós da árvore. Aqui a
/// ideia também é usar uma abordagem recursiva de bottom-up.

pub fn busca(arv: Arvore(Int)) -> Bool {
    case arv {
        No(val, dir, Vazia) -> val <= busca(dir)
        No(val, Vazia, esq) -> val >= busca(esq)
        No(val, Vazia, Vazia) -> val
        No(val, dir, esq) -> val >= busca(esq) && val <= busca(dir)
    }
}

/// Essa função deve achar o valor mínimo de uma árvore binária

pub fn min_val(arv: Arvore(a)) -> 

/// Essa função deve achar o valor máximo de uma parvore binária

pub fn busca_examples() {
    check.eq(busca(No(1, No(0, Vazia, Vazia), No(2, Vazia, Vazia))), True)
    check.eq(busca(No(1, No(0, No(2, Vazia, Vazia), Vazia), No(2, Vazia, Vazia))), False)
    check.eq(busca(No(1, No(0, No(2, Vazia, Vazia), Vazia), No(2, No(2, Vazia, No(3, Vazia, Vazia)), No(2, Vazia, Vazia)))), True)
}