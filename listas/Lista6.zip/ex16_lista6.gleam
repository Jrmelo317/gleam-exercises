import sgleam/check
import gleam/result
import gleam/int

/// Essa função verifica se uma árvore binária está balanceada, de acordo com as regras avl
/// de balanceamento. Faz isso usando recursividade e uma implementação bottom-up.

pub type Arvore(a) {
    Vazia
    No(val: a, dir: Arvore(a), esq: Arvore(a))
}

pub fn balanceada(arv: Arvore(a)) -> Result(Int, Nil) {
    case arv {
        Vazia -> Ok(-1)
        No(_, dir, esq) -> {
            use alt_esq <- result.try(balanceada(esq))
            use alt_dir <- result.try(balanceada(dir))

            let dif = int.absolute_value(alt_esq - alt_dir)

            if dif <= 1 {
                Ok(1 + int.max(alt_esq, alt_dir))
            } else {
                Error(Nil)
            }
        }
    }
}

pub fn balanceada_examples() {
    check.eq(balanceada(No(1, Vazia, Vazia)), Ok(0))
    check.eq(balanceada(No(1, No(1, Vazia, Vazia), Vazia)), Ok(1))
    check.eq(balanceada(No(1, No(1, Vazia, Vazia), No(1, Vazia, Vazia))), Ok(1))
    check.eq(balanceada(No(1, No(1, No(1, Vazia, Vazia), Vazia), Vazia)), Error(Nil))
    check.eq(balanceada(No(1, No(1, No(1, Vazia, Vazia), Vazia), No(1, Vazia, Vazia))), Ok(2))
}