import sgleam/check

/// Essa função deve receber uma lista de elementos, e retornar uma lista
/// com os mesmos elementos em ordem contrária.

pub fn lista_ao_contrario(lista: List(a)) -> List(a) {
    case lista {
        [] -> []
        [primeiro, ..resto] -> []
    }
}

pub fn lista_ao_contrario_examples() {
    check.eq(lista_ao_contrario([1, 2, 3]), [3, 2, 1])
    check.eq(lista_ao_contrario([]), [])
    check.eq(lista_ao_contrario(["a", "b"]), ["b", "a"])
}

/// Função auxiliar, que basicamente adicinar um elemento ao final de uma lista
/// e retorna esta lista com esse elemento em seu fim.

pub fn adiciona_fim(lista: List(a), elemento: a) -> List(a) {
    case lista {
        [] -> [elemento]
        [primeiro, ..resto] -> [primeiro, ..adiciona_fim(resto, elemento)]
    }
}

pub fn adiciona_fim_examples() {
    check.eq(adiciona_fim([1, 2], 3), [1, 2, 3])
    check.eq(adiciona_fim(["a", "b"], "c"), ["a", "b", "c"])
    check.eq(adiciona_fim([], 1), [1])
}