import sgleam/check
import gleam/string
import gleam/int
import gleam/result

///Essa função gera a partir de um n inteiro, - que representa a quantidade de caracteres da mensagem que serão
///exibidos por vez - momento - que representa em qual momento a mensagem está sendo exibida -  e uma mensagem - string -.
/// Para fazer isso, calcula o modulo de momento em relação ao tamanho da palavra, exibindo a quantidade n de caracteres
/// a partir do resultado do modulo.


///Implementar Unwrap em INT.REMAINDER E VER A NECESSIDADE EM SLICE

pub fn exibicao_letreiro(momento: Int, quantidade_caracter: Int, palavra: String) -> String {
    let tam = string.length(palavra)
    let indice_inicio_exibicao = int.remainder(momento, tam)
    let quantidade_indices = tam - 1
    case tam < indice_inicio_exibicao + quantidade_caracter {
        True -> {
            let parte_inicial = string.slice(palavra, indice_inicio_exibicao, tam)
            let parte_final = string.slice(palavra, 0, quantidade_indices - indice_inicio_exibicao)
            string.concat([parte_inicial, parte_final])
        }
        False -> {
            string.slice(palavra, indice_inicio_exibicao, quantidade_caracter)
        }
    }
}

pub fn exibicao_letreiro_examples() {
  // --- Testes com a mensagem "JOAO" e letreiro de tamanho 3 ---

  // Teste 1: Momento 0, o início da exibição.
  check.eq(exibicao_letreiro(0, 3, "JOAO"), "JOA")

  // Teste 2: Momento 1, a primeira "volta", pegando o fim e o começo.
  check.eq(exibicao_letreiro(1, 3, "JOAO"), "OAJ")

  // Teste 3: Momento 3, outra "volta".
  check.eq(exibicao_letreiro(3, 3, "JOAO"), "OJO")

  // Teste 4: Momento 4, completou um ciclo, deve ser igual ao momento 0.
  check.eq(exibicao_letreiro(4, 3, "JOAO"), "JOA")

  // Teste 5: Momento 8, completou dois ciclos, também deve ser igual ao momento 0.
  // Este é o teste que você forneceu.
  check.eq(exibicao_letreiro(8, 3, "JOAO"), "JOA")

  // --- Testes com uma mensagem mais longa para maior clareza ---
  let mensagem = "ABCDEFG" // Tamanho 7
  let tamanho_letreiro = 4

  // Teste 6: Exibição simples, sem dar a volta.
  check.eq(exibicao_letreiro(1, tamanho_letreiro, mensagem), "BCDE")

  // Teste 7: Exibição chegando exatamente no final da string.
  check.eq(exibicao_letreiro(3, tamanho_letreiro, mensagem), "DEFG")

  // Teste 8: Primeiro momento que exige a "volta".
  check.eq(exibicao_letreiro(4, tamanho_letreiro, mensagem), "EFGA")

  // Teste 9: Momento grande para garantir que a lógica de módulo funciona.
  // 15 % 7 = 1. Deve ser igual ao momento 1.
  check.eq(exibicao_letreiro(15, tamanho_letreiro, mensagem), "BCDE")
}