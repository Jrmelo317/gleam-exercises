1) Quais são as etapas do processo de projeto de funções?

O projeto de funções, consiste em um processo que conta com 6 etapas principais, listarei elas em ordem cronológica de execução durante o processo: análise, definição dos tipos de dados, especificação, implementação, verificação e revisão.

2) Qual é o propósito da análise?

A etapa da análise tem como propósito responder a perguntas que, quando respondidas, estruturem um texto que sirva para determinar o que uma função ou um projeto deve realizar ao estar pronto, identificando o problema a ser resolvido, desta forma a análise apoia também a etapa de verificação.

3) Qual é o propósito da definição dos tipos de dados?

O propósito da definição dos tipos de dados é dizer como as informações do mundo real serão representadas no programa, e o por que disso.

4) Quais são as partes que compõem a especificação de uma função?

A especificação contém três partes principais, a descrição do propósito de uma função (o que ela faz), a assinatura da função (o que ela recebe como parâmetros e qual o tipo do retorno) e exemplos de entrada e saída.

5) Qual é a principal propriedade que uma especificação deve ter para ser considerada adequada?

A principal propriedade que uma especificação deve atender para ser considera adequada é, possibilitar que outro desenvolvedor que não tem acesso ao problema inicial e ne a análise, tenha as informação necessárias para fazer uma implementação e verificação inicial.

6) O que é a assinatura de uma função?

A assinatura da função é a descrição do nome da função, o seu escopo (pub ou não), os parâmetros que irá receber e o tipo de cada um deles e o tipo esperado no retorno de uma função.

7) Qual é o objetivo inicial dos exemplos no projeto de uma função? E os demais objetivos?

O objetivo inicial dos exemplos no projeto de uma função é ajudar o projetista a entender como a saída de uma função pode ser obtida a partir da entradas e ilustrar o funcionamento da função para que a especificação fique mais clara. Além disso, são os exemplos que servem de verificação para o funcionamento de uma função.

8) Se não forem encontrados erros na verificação para os exemplos da especificação, é possível afirmar que a função está isenta de erros? Explique.

Não, primeiro pois os exemplos podem estar escritos de forma incorreta e portanto não são válidos como verificação, além disso, pode ser que ocorra um erro apenas em um caso específico de uma função, que não está sendo testado pelos exemplos, portanto não foi verificado.

9) A implementação é a fase mais importante do projeto de funções, verdadeiro ou falso? Explique.
   
   Eu diria que sim, pois a implementação é o que impacta no real uso de um sistema e de uma função por ele, desta forma, para um sistema funcionar basta que a sua implementação esteja correta, e o intuito de todas as outras etapas do processo gira em torno de verificar, validar e facilitar a fase de implementação.

9) Como proceder quando um teste falha?

Quando um teste falha, devemos verificar se o teste foi escrito de forma correta, se sim, devemos buscar corrigir a implementação da função, e para isso devemos entender o motivo daquele teste estar falhando, para assim corrigirmos a falha.

11) Qual é o objetivo da revisão?

O objetivo da etapa de revisão é buscar por erros que podem ter passados despercebidos nas outras etapas, ou melhorias que possam ser feitas no código, deixando ele mais bem escrito ou mais eficiente por exemplo.

12) Qual é a diferença do resultado da análise e a descrição do propósito da função?

No propósito da função descrevemos o que uma função faz, em quanto isso, na etapa da análise buscamos entender qual o problema a ser resolvido. Então podemos dizer que a análise é realizada antes da descrição do propósito de uma função, além disso a análise pode servir para mais de uma função.